const express = require('express');
const { createTicket, assignUserToTicket, getTicketById, getAssignedUsers, getTicketAnalytics } = require('../models/ticketModel');
const { verifyToken } = require('../utils/jwt');
const router = express.Router();

router.post('/', async (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    const userData = verifyToken(token);

    if (!userData) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
        const ticketData = { ...req.body, createdBy: userData.id };
        const ticket = await createTicket(ticketData);
        res.status(201).json(ticket);
    } catch (error) {
        res.status(500).json({ message: 'Error creating ticket' });
    }
});

router.post('/:ticketId/assign', async (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    const userData = verifyToken(token);

    if (!userData) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    const { userId } = req.body;
    const ticketId = req.params.ticketId;

    try {
        const ticket = await getTicketById(ticketId);

        if (ticket.status === 'closed') {
            return res.status(400).json({ message: 'Cannot assign users to a closed ticket' });
        }

        if (ticket.created_by !== userData.id && userData.type !== 'admin') {
            return res.status(403).json({ message: 'Unauthorized to assign users to this ticket' });
        }

        const assignedUsers = await getAssignedUsers(ticketId);
        if (assignedUsers.length >= 5) {
            return res.status(400).json({ message: 'User assignment limit reached' });
        }

        const userAlreadyAssigned = assignedUsers.find(user => user.id === userId);
        if (userAlreadyAssigned) {
            return res.status(400).json({ message: 'User already assigned' });
        }

        const assignment = await assignUserToTicket(ticketId, userId);
        res.status(200).json({ message: 'User assigned successfully', assignment });
    } catch (error) {
        res.status(500).json({ message: 'Error assigning user to ticket' });
    }
});

router.get('/:ticketId', async (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    const userData = verifyToken(token);

    if (!userData) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    try {
        const ticket = await getTicketById(req.params.ticketId);
        if (ticket) {
            const assignedUsers = await getAssignedUsers(ticket.id);
            ticket.assignedUsers = assignedUsers;
            res.json(ticket);
        } else {
            res.status(404).json({ message: 'Ticket not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving ticket' });
    }
});

router.get('/analytics', async (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    const userData = verifyToken(token);

    if (!userData) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    const filters = {
        startDate: req.query.startDate,
        endDate: req.query.endDate,
        status: req.query.status,
        priority: req.query.priority,
        type: req.query.type,
        venue: req.query.venue,
    };

    try {
        const analytics = await getTicketAnalytics(filters);
        res.json(analytics);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving analytics' });
    }
});

module.exports = router;