const pool = require('../database');
const bcrypt = require('bcrypt');

async function createUser(name, email, type, password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
        'INSERT INTO public.users (name, email, type, password) VALUES ($1, $2, $3, $4) RETURNING id, name, email, type',
        [name, email, type, hashedPassword]
    );
    return result.rows[0];
}

async function getUserByEmail(email) {
    const result = await pool.query('SELECT * FROM public.users WHERE email = $1', [email]);
    return result.rows[0];
}

module.exports = { createUser, getUserByEmail };