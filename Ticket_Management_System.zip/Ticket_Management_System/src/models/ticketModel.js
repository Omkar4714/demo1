const pool = require('../database');

async function createTicket(data) {
    const { title, description, type, venue, status, price, priority, dueDate, createdBy } = data;
    const result = await pool.query(
        `INSERT INTO public.tickets (title, description, type, venue, status, price, priority, due_date, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
        [title, description, type, venue, status, price, priority, dueDate, createdBy]
    );
    return result.rows[0];
}

async function assignUserToTicket(ticketId, userId) {
    const result = await pool.query(
        `INSERT INTO public.ticket_assignments (ticket_id, user_id) 
        VALUES ($1, $2) RETURNING *`,
        [ticketId, userId]
    );
    return result.rows[0];
}

async function getTicketById(ticketId) {
    const result = await pool.query(
        `SELECT public.tickets.*, public.users.name AS created_by_name FROM public.tickets 
        JOIN users ON tickets.created_by = users.id 
        WHERE public.tickets.id = $1`, [ticketId]);
    return result.rows[0];
}

async function getAssignedUsers(ticketId) {
    const result = await pool.query(
        `SELECT public.users.id, public.users.name, public.users.email FROM public.ticket_assignments 
        JOIN users ON public.ticket_assignments.user_id = users.id 
        WHERE public.ticket_assignments.ticket_id = $1`, [ticketId]);
    return result.rows;
}

async function getTicketAnalytics(filters) {
    const conditions = [];
    const values = [];

    if (filters.startDate) {
        conditions.push('created_date >= $' + (conditions.length + 1));
        values.push(filters.startDate);
    }
    if (filters.endDate) {
        conditions.push('created_date <= $' + (conditions.length + 1));
        values.push(filters.endDate);
    }
    if (filters.status) {
        conditions.push('status = $' + (conditions.length + 1));
        values.push(filters.status);
    }
    if (filters.priority) {
        conditions.push('priority = $' + (conditions.length + 1));
        values.push(filters.priority);
    }
    if (filters.type) {
        conditions.push('type = $' + (conditions.length + 1));
        values.push(filters.type);
    }
    if (filters.venue) {
        conditions.push('venue = $' + (conditions.length + 1));
        values.push(filters.venue);
    }

    const whereClause = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

    const query = `
        SELECT 
            COUNT(*) AS totalTickets,
            COUNT(CASE WHEN status = 'closed' THEN 1 END) AS closedTickets,
            COUNT(CASE WHEN status = 'open' THEN 1 END) AS openTickets,
            COUNT(CASE WHEN status = 'in-progress' THEN 1 END) AS inProgressTickets,
            COUNT(CASE WHEN priority = 'low' THEN 1 END) AS lowPriorityTickets,
            COUNT(CASE WHEN priority = 'medium' THEN 1 END) AS mediumPriorityTickets,
            COUNT(CASE WHEN priority = 'high' THEN 1 END) AS highPriorityTickets,
            COUNT(CASE WHEN type = 'concert' THEN 1 END) AS concertTickets,
            COUNT(CASE WHEN type = 'conference' THEN 1 END) AS conferenceTickets,
            COUNT(CASE WHEN type = 'sports' THEN 1 END) AS sportsTickets
        FROM public.tickets
        ${whereClause}
    `;

    const result = await pool.query(query, values);
    return result.rows[0];
}

module.exports = { createTicket, assignUserToTicket, getTicketById, getAssignedUsers, getTicketAnalytics };