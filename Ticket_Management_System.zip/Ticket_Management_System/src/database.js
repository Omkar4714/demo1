const { Pool } = require('pg');

const pool = new Pool({
  user: 'omkar',
  host: 'localhost',
  database: 'ticketmanagement',
  password: 'Omkar@123',
  port: 5432,
});

module.exports = pool;